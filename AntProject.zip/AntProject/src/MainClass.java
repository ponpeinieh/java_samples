
public class MainClass {

    public static void main(String[] args) {
        Staff s = Staff.createStaff();
        ObjectMapper mapper = new ObjectMapper();
        // Java objects to JSON string - compact-print
        String jsonString = mapper.writeValueAsString(s);
        System.out.println(jsonString);
    }
}
