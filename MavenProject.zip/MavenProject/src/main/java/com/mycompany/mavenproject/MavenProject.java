

package com.mycompany.mavenproject;

/**
 *
 * @author pi
 */
public class MavenProject {

    public static void main(String[] args) {
        Staff s = Staff.createStaff();
        ObjectMapper mapper = new ObjectMapper();
        // Java objects to JSON string - compact-print
        String jsonString = mapper.writeValueAsString(s);
        System.out.println(jsonString);
    }
}
